<div class="col-md-3">
          <ul class="nav nav-pills">
            <li class="Home">
              <a href="#">&nbsp;&nbsp;</a>
            </li>
          </ul>
          <div class="sidebar content-box" style="display: block ;position: fixed;">
            <ul class="nav">
              <!-- 	Sidebar menu -->
              <li class="current">
                <a href="home.php"><i class="glyphicon glyphicon-home"></i> Home </a>
              </li>
              <li class="aboutus">
                <a href="general_information.php"> About us </a>
              </li>
              <li class="todolist">
                <a href="to_do_list.php">To Do List</a>
              </li>
              <li class="nceac">
                <a href="nceac_forms.php"> NCEAC Forms </a>
              </li>
              <li class="previous">
                <a href="previous_forms.php"> Previous Forms</a>
              </li>
			  <li class="currentdocs">
                <a href="current.php">Current Document</a>
              </li>
              <li class="feedback">
                <a href="feedback.php"> Feedback&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </a>
              </li>
			  
            </ul>
            <ul class="nav"></ul>
          </div>
        </div>