<html><head>
    <title>NCEAC Document Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- jQuery UI -->
    <link href="https://code.jquery.com/ui/1.10.3/themes/redmond/jquery-ui.css" rel="stylesheet" media="screen">
    <!-- Bootstrap -->
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- styles -->
    <link href="css/styles.css" rel="stylesheet">
    <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
    <link href="vendors/form-helpers/css/bootstrap-formhelpers.min.css" rel="stylesheet">
    <link href="vendors/select/bootstrap-select.min.css" rel="stylesheet">
    <link href="vendors/tags/css/bootstrap-tags.css" rel="stylesheet">
    <link href="css/forms.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media
    queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file://
    -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
      body {
                                                                                                                        background-image: url("background2.jpg");
                                                                                                                    }
    </style>
  </head><body>
    <div class="header">
      <div class="container">
        <div class="row">
          <div class="col-md-6" draggable="true">
            <!-- Logo -->
            <div class="logo">
              <h1>
                <a href="home.php">NCEAC Document Management System</a>
              </h1>
            </div>
          </div>
          <div class="col-md-4">
            <div class="row">
              <div class="col-md-12">
                <div class="input-group form">
                  <input type="text" class="form-control" placeholder="Search...">
                  <span class="input-group-btn">
                    <button class="btn btn-primary" type="button">Search</button>
                  </span>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-2">
            <div class="navbar navbar-inverse" role="banner">
              <nav class="collapse navbar-collapse bs-navbar-collapse navbar-right" role="navigation">
                <ul class="nav navbar-nav">
                  <li class="dropdown user user-menu">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="user.png" class="img-circle" alt="User Image" width="30" height="30">&nbsp;<span class="caret"></span>
              </a>
                    <ul class="dropdown-menu animated fadeInUp">
                      <li>
                        <a href="profile.php">Profile</a>
                      </li>
                      <li>
                        <a href="accountsetting.php">Setting</a>
                      </li>
                      <li>
                        <a href="logout.php">Logout</a>
                      </li>
                    </ul>
                  </li>
                </ul>
              </nav>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="page-content">
      <div class="row">
        <div class="col-md-3">
          <ul class="nav nav-pills">
            <li class="h">
              <a href="#">&nbsp;&nbsp;</a>
            </li>
          </ul>
          <div class="sidebar content-box" style="display: block;">
            <ul class="nav">
              <!-- Main menu -->
              <li class="general">
                <a href="home.php"><i class="glyphicon glyphicon-home"></i> Home </a>
              </li>
              <li class="aboutus">
                <a href="general_information.php"> About us </a>
              </li>
              <li class="nceactodolist">
                <a href="to_do_list.php">To Do List</a>
              </li>
              <li class="nceac">
                <a href="nceac_forms.php"> NCEAC Forms </a>
              </li>
              <li class="current">
                <a href="previous_forms.php"> Previous Forms</a>
              </li>
			   <li class="currentdocs">
                <a href="current.php">Current Document</a>
              </li>
              <li class="feedback">
                <a href="feedback.php"> Feedback </a>
              </li>
            </ul>
            <ul class="nav"></ul>
          </div>
        </div>
        <div class="col-md-9">
          <ul class="nav nav-pills">
           <li>
              <a href="#">Notification&nbsp;<span class="glyphicon glyphicon-bell"></span></a>
            </li>
            <li>
              <a href="#">Notice Board&nbsp;<span class="badge">2</span></a>
            </li>
          </ul>
          <div class="row">
            <div class="col-md-11 panel-default text-center">
              <u></u>
              <div class="panel panel-primary">
                <u>
                  <div class="container-fluid">
                    <div class="panel panel-primary">
                      <div class="panel-heading">
                        <h3 class="panel-body">Pervious Forms</h3>
                      </div>
                    </div>
                  </div>
                  <div class="panel-body">
                    <ul class="list-group text-left">
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="1RequestforEvaluation(RFE).php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Request for Evaluation-(RFE) </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="2AdminStructure.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Admin Structure </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="3Admission.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Admission </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="4StudentInformation.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Student Information </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="5CourseDescription.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Course Description </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="6CourseLogTemplate(CLT).php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Course Log Template (CLT) </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="7CourseMonitoringProcess (CMPF).php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Course Monitoring Process (CMPF) </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="8ProgramMonitoringProcess(PMPF).php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Program Monitoring Process (PMPF) </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="9CourseRegistration.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Course Registration </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="10CurriculumRelatedInformation.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Curriculum Related Information </a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="11Financial.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Financial</a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="12FacultyInformationFIF.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Faculty Information-FIF</a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="13GradingPolicy.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Grading Policy</a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="14Infrastructure.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Infrastructure</a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="15Alumni.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Alumni</a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="16CourseDisplayfortheVisit.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Course Display for the Visit</a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="17FieldAuditGuidelines-DR.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Field Audit Guidelines-DR</a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                      <li class="list-group-item">
                        <p class="text-left">
                          <a href="18FieldAuditSchedule.php" target="_blank">
                       <i class="glyphicon glyphicon-file"></i>&nbsp;Field Audit Schedule</a>
                        </p>
                        <div align="right">
                          <span class="label label-primary">Assign Date</span>
                          <span class="label label-default">Due Date</span>
                          <span class="label label-success">Activity</span>
                        </div>
                      </li>
                    </ul>
                  </div>
                </u>
              </div>
              <u></u>
            </div>
          </div>
        </div>
      </div>
    </div>
    <u>
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
      <script src="https://code.jquery.com/jquery.js"></script>
      <!-- jQuery UI -->
      <script src="https://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
      <!-- Include all compiled plugins (below), or include individual
      files as needed -->
      <footer class="section section-primary">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <div class="footer-widget">
                <div class="featured-links" style="heigh:500px; width:600px;">
                  <h5>Featured Links</h5>
                  <div class="line-dec"></div>
                  <ul>
                    <li>
                      <a href="careers">Careers</a>
                    </li>
                    <li>
                      <a href="admissions">Admissions</a>
                    </li>
                    <li>
                      <a href="downloads">Downloads</a>
                    </li>
                    <li>
                      <a href="news">News / Happenings</a>
                    </li>
                  </ul>
                  <ul>
                    <li>
                      <a href="sitemap">Sitemap</a>
                    </li>
                    <li>
                      <a href="mailto:info@uit.edu">Feedback</a>
                    </li>
                    <li>
                      <a href="undergraduate-programs">Programmes</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="footer-widget">
                <div class="university-address">
                  <h5>Contact Details</h5>
                  <div class="line-dec"></div>
                  <ul>
                    <li>
                      <i class="fa fa-fax"></i>+92 (213) 49 76181</li>
                    <li>
                      <i class="fa fa-fax"></i>+92 (213) 499 4305</li>
                    <li>
                      <i class="fa fa-envelope-o"></i>
                      <a style="color: #d6d6d6;" href="mailto:info@odms.edu">info@odms.edu</a>&nbsp;</li>
                    <li>
                      <i class="fa fa-phone"></i>+92 (213) 499 4305</li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <p class="text-info text-right">
                <br>
                <br>
              </p>
              <div class="row">
                <div class="col-md-12 hidden-lg hidden-md hidden-sm text-left">
                  <a href="#"><i class="fa fa-3x fa-fw fa-instagram text-inverse"></i></a>
                  <a href="#"><i class="fa fa-3x fa-fw fa-twitter text-inverse"></i></a>
                  <a href="#"><i class="fa fa-3x fa-fw fa-facebook text-inverse"></i></a>
                  <a href="#"><i class="fa fa-3x fa-fw fa-github text-inverse"></i></a>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 hidden-xs text-right">
                  <a href="#"><i class="fa fa-3x fa-fw fa-instagram text-inverse"></i></a>
                  <a href="#"><i class="fa fa-3x fa-fw fa-twitter text-inverse"></i></a>
                  <a href="#"><i class="fa fa-3x fa-fw fa-facebook text-inverse"></i></a>
                  <a href="#"><i class="fa fa-3x fa-fw fa-github text-inverse"></i></a>
                  <div class="row">
                    <div class="col-md-120">
                      <div class="copyright-menu">
                        <div class="row">
                          <div class="col-md-6">
                            <div class="copyright-text">
                              <p class="text-left" contenteditable="true">Copyright © 2016</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </u>
    <u>
      <u></u>
    </u>
  

</body></html>