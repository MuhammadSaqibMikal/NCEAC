<?php
	include 'header.php';
?>

    <div class="page-content">
      <div class="row">
       
	   <?php
		include 'sidebar.php';
	   ?>
        <div class="col-md-8">
          <ul class="nav nav-pills">
            <li>
              <a href="notification.php">Notification&nbsp;<span class="glyphicon glyphicon-bell"></span></a>
            </li>
            <li>
              <a href="noticeboard.php">Notice Board&nbsp;<span class="badge">2</span></a>
            </li>
           </ul>
          <div class="row">
		  
          <section class="widget">
        <div class="widget-body">
            <div class="widget-top-overflow windget-padding-md clearfix bg-primary text-white">
                <h3 class="mt-lg mb-lg">Assignment- <span class="fw-semi-bold">Title</span> Name</h3>
                <ul class="tags text-white pull-right">
                    <li><a href="#">features</a></li>
                </ul>
            </div>
            <div class="post-user mt-n-lg">
                <h5 class="mt-sm fw-normal text-white">Start Date <small class="text-white text-light">Priority</small></h5>
                <p class="fs-mini text-muted"><time>Deadline</time> &nbsp; <i class="fa fa-map-marker"></i> &nbsp; location</p>
            </div>
            <p class="text-light fs-mini m">Add your task description here description here  </p>
        </div>
    </section>
	<section class="widget">
        <div class="widget-body">
            <div class="widget-top-overflow windget-padding-md clearfix bg-primary text-white">
                <h3 class="mt-lg mb-lg">Assignment- <span class="fw-semi-bold">Title</span> Name</h3>
                <ul class="tags text-white pull-right">
                    <li><a href="#">features</a></li>
                </ul>
            </div>
            <div class="post-user mt-n-lg">
                <h5 class="mt-sm fw-normal text-white">Start Date <small class="text-white text-light">Priority</small></h5>
                <p class="fs-mini text-muted"><time>Deadline</time> &nbsp; <i class="fa fa-map-marker"></i> &nbsp; location</p>
            </div>
            <p class="text-light fs-mini m">Add your task description here description here  </p>
        </div>
    </section><section class="widget">
        <div class="widget-body">
            <div class="widget-top-overflow windget-padding-md clearfix bg-primary text-white">
                <h3 class="mt-lg mb-lg">Assignment- <span class="fw-semi-bold">Title</span> Name</h3>
                <ul class="tags text-white pull-right">
                    <li><a href="#">features</a></li>
                </ul>
            </div>
            <div class="post-user mt-n-lg">
                <h5 class="mt-sm fw-normal text-white">Start Date <small class="text-white text-light">Priority</small></h5>
                <p class="fs-mini text-muted"><time>Deadline</time> &nbsp; <i class="fa fa-map-marker"></i> &nbsp; location</p>
            </div>
            <p class="text-light fs-mini m">Add your task description here description here  </p>
        </div>
    </section>
<section class="widget">
        <div class="widget-body">
            <div class="widget-top-overflow windget-padding-md clearfix bg-primary text-white">
                <h3 class="mt-lg mb-lg">Assignment- <span class="fw-semi-bold">Title</span> Name</h3>
                <ul class="tags text-white pull-right">
                    <li><a href="#">features</a></li>
                </ul>
            </div>
            <div class="post-user mt-n-lg">
                <h5 class="mt-sm fw-normal text-white">Start Date <small class="text-white text-light">Priority</small></h5>
                <p class="fs-mini text-muted"><time>Deadline</time> &nbsp; <i class="fa fa-map-marker"></i> &nbsp; location</p>
            </div>
            <p class="text-light fs-mini m">Add your task description here description here  </p>
        </div>
    </section>	
          </div>
        </div>
      </div>
    </div>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual
    files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
    
	<?php
		include 'footer.php';
	?>