<?php	
include 'header.php';
?>
    
	
<?php	
include 'midpanel.php';
?>    
	   
<?php	
include 'footer.php';
?>