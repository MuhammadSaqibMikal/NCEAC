-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2017 at 09:01 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `fyp`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminstructure`
--

CREATE TABLE IF NOT EXISTS `adminstructure` (
`AdminStructure_Form_Id` int(10) NOT NULL,
  `AdminStructure_Submit_Date` date DEFAULT NULL,
  `AdminStructure_Assign_Date` date DEFAULT NULL,
  `AdminStructure_Status` varchar(30) DEFAULT NULL,
  `AdminStructure_Instituition` varchar(100) DEFAULT NULL,
  `AdminStructure_Evaluate` varchar(100) DEFAULT NULL,
  `AdminStructure_Name` varchar(100) DEFAULT NULL,
  `AdminStructure_Address` varchar(100) DEFAULT NULL,
  `AdminStructure_Name_Of_Chief` varchar(100) DEFAULT NULL,
  `AdminStructure_Administrative` varchar(100) DEFAULT NULL,
  `AdminStructure_Board` varchar(100) DEFAULT NULL,
  `AdminStructure_Bodies` varchar(100) DEFAULT NULL,
  `Emp_Id` varchar(30) DEFAULT NULL,
  `Admin_Structure_Post_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adminstructureb`
--

CREATE TABLE IF NOT EXISTS `adminstructureb` (
  `Name_Degree_Program` varchar(100) DEFAULT NULL,
  `Enrollment` varchar(100) DEFAULT NULL,
  `Full_Time_Faculty_Size` varchar(100) DEFAULT NULL,
  `Faculty_Strength` varchar(100) DEFAULT NULL,
  `MathematicsFt` varchar(100) DEFAULT NULL,
  `MathematicsFte` varchar(100) DEFAULT NULL,
  `Natural_ScienceFt` varchar(100) DEFAULT NULL,
  `Natural_ScienceFte` varchar(100) DEFAULT NULL,
  `HumanitiesFt` varchar(100) DEFAULT NULL,
  `HumanitiesFte` varchar(100) DEFAULT NULL,
  `AdminStructure_Form_Id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE IF NOT EXISTS `admission` (
`Form_Id` int(10) NOT NULL,
  `Admission_Date_To_Be_Submitted` date DEFAULT NULL,
  `Admission_Assign_Date` date DEFAULT NULL,
  `Admission_Status` varchar(50) DEFAULT NULL,
  `AdmissionInstituteName` varchar(50) DEFAULT NULL,
  `ProgramEvalute` varchar(50) DEFAULT NULL,
  `FrequencyAdmission` varchar(500) DEFAULT NULL,
  `NewStdAdmission` varchar(500) DEFAULT NULL,
  `NewInstruments` varchar(500) DEFAULT NULL,
  `AdmissionRqm` varchar(500) DEFAULT NULL,
  `IsOpenMerit` varchar(500) DEFAULT NULL,
  `HowMerit` varchar(500) DEFAULT NULL,
  `StdPerAdmission` varchar(500) DEFAULT NULL,
  `Emp_Id` varchar(50) DEFAULT NULL,
  `Admission_Post_Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `coursedescription`
--

CREATE TABLE IF NOT EXISTS `coursedescription` (
`Course_Form_Id` int(10) NOT NULL,
  `Course_Submit_Date` date DEFAULT NULL,
  `Course_Assign_Date` date DEFAULT NULL,
  `Course_Status` varchar(30) DEFAULT NULL,
  `Course_Post_Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Emp_Id` varchar(30) DEFAULT NULL,
  `CourseDescription_InstituteName` varchar(50) DEFAULT NULL,
  `CourseDescription_Evalute` varchar(50) DEFAULT NULL,
  `Course_Code` varchar(20) DEFAULT NULL,
  `Course_Title` varchar(20) DEFAULT NULL,
  `Credit_Hours` varchar(20) DEFAULT NULL,
  `Prerequisites` varchar(100) DEFAULT NULL,
  `Assessments` varchar(100) DEFAULT NULL,
  `Course_Coordinator` varchar(20) DEFAULT NULL,
  `Url` varchar(20) DEFAULT NULL,
  `Current_Catalog` varchar(50) DEFAULT NULL,
  `Textbook` varchar(100) DEFAULT NULL,
  `Reference_Material` varchar(100) DEFAULT NULL,
  `Course_Goals` varchar(100) DEFAULT NULL,
  `Topics_Covered` varchar(100) DEFAULT NULL,
  `Laboratory_Projects` varchar(100) DEFAULT NULL,
  `Programming_Assignments` varchar(100) DEFAULT NULL,
  `Class_Theory` varchar(20) DEFAULT NULL,
  `Class_Problem` varchar(20) DEFAULT NULL,
  `Class_Solution` varchar(20) DEFAULT NULL,
  `Class_Social` varchar(20) DEFAULT NULL,
  `Oral1` varchar(50) DEFAULT NULL,
  `Oral2` varchar(50) NOT NULL,
  `Oral3` varchar(50) NOT NULL,
  `Oral4` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `courselog`
--

CREATE TABLE IF NOT EXISTS `courselog` (
`CourseLog_Form_Id` int(10) NOT NULL,
  `CourseLog_InstituteName` varchar(50) DEFAULT NULL,
  `CourseLog_Submit_Date` date DEFAULT NULL,
  `CourseLog_Assign_Date` date DEFAULT NULL,
  `CourseLog_Status` varchar(20) DEFAULT NULL,
  `CourseLog_Post_Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CourseLog_Evaluation` varchar(50) DEFAULT NULL,
  `CourseLog_Course_Name` varchar(50) DEFAULT NULL,
  `CourseLog_Catalog_Number` varchar(50) DEFAULT NULL,
  `CourseLog_Instructor_Name` int(50) DEFAULT NULL,
  `CourseLog_Date` date DEFAULT NULL,
  `CourseLog_Duration` varchar(20) DEFAULT NULL,
  `CourseLog_Topics_Covered` varchar(20) DEFAULT NULL,
  `CourseLog_Evaluation_Instruments` varchar(20) DEFAULT NULL,
  `Emp_Id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `coursemonitoring`
--

CREATE TABLE IF NOT EXISTS `coursemonitoring` (
`coursemonitoring_Form_Id` int(10) NOT NULL,
  `coursemonitoring_Submit_Date` date DEFAULT NULL,
  `coursemonitoring_Assign_Date` date DEFAULT NULL,
  `coursemonitoring_Status` varchar(20) DEFAULT NULL,
  `coursemonitoring_Post_Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `coursemonitoring_InstituteName` varchar(50) DEFAULT NULL,
  `coursemonitoring_Evaluation` varchar(50) DEFAULT NULL,
  `Cm_Objective` varchar(50) DEFAULT NULL,
  `Cm_FullCoverage` varchar(50) DEFAULT NULL,
  `Cm_Relevant` varchar(50) DEFAULT NULL,
  `Cm_Assessment` varchar(50) DEFAULT NULL,
  `Cm_Application` varchar(50) DEFAULT NULL,
  `Emp_Id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `courseregistration`
--

CREATE TABLE IF NOT EXISTS `courseregistration` (
`CR_Form_Id` int(10) NOT NULL,
  `CR_Submit_Date` date DEFAULT NULL,
  `CR_Assign_Date` date DEFAULT NULL,
  `CR_Status` varchar(20) DEFAULT NULL,
  `CR_Post_Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CR_InstituteName` varchar(30) DEFAULT NULL,
  `CR_Evaluation` varchar(30) DEFAULT NULL,
  `CR_When_is_pre` varchar(50) DEFAULT NULL,
  `CR_How_is_pre` varchar(50) DEFAULT NULL,
  `CR_When_is_late` varchar(50) DEFAULT NULL,
  `CR_What_is_panelty` varchar(50) DEFAULT NULL,
  `CR_When_is_Allowed` varchar(50) DEFAULT NULL,
  `CR_What_is_policy` varchar(50) DEFAULT NULL,
  `CR_What_policy_regarding` varchar(50) DEFAULT NULL,
  `CR_E_Minimum_Maximum` varchar(50) DEFAULT NULL,
  `CR_Process_Ensure` varchar(50) DEFAULT NULL,
  `Emp_Id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `curriculumrelatedinformation`
--

CREATE TABLE IF NOT EXISTS `curriculumrelatedinformation` (
`CRI_Form_Id` int(10) NOT NULL,
  `CRI_Submit_Date` date DEFAULT NULL,
  `CRI_Assign_Date` date DEFAULT NULL,
  `CRI_Status` varchar(20) DEFAULT NULL,
  `CRI_Post_Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `CRI_InstituteName` varchar(30) DEFAULT NULL,
  `CRI_Evaluation` varchar(30) DEFAULT NULL,
  `CRI_Computing_Hours` varchar(30) DEFAULT NULL,
  `CRI_Major_Core` varchar(30) DEFAULT NULL,
  `CRI_Major_Based` varchar(30) DEFAULT NULL,
  `CRI_Supporting` varchar(30) DEFAULT NULL,
  `CRI_General` varchar(30) DEFAULT NULL,
  `CRI_University` varchar(30) DEFAULT NULL,
  `CRI_Total Credit` varchar(30) DEFAULT NULL,
  `CRI_Cumulative_Credit_HoursA` varchar(30) DEFAULT NULL,
  `CRI_Cumulative_Credit_HoursB` varchar(30) DEFAULT NULL,
  `CRI_Cumulative_Credit_HoursTotal` varchar(30) DEFAULT NULL,
  `CRI_Core_Courses_Code` varchar(30) DEFAULT NULL,
  `CRI_Core_Courses_Title` varchar(30) DEFAULT NULL,
  `CRI_Core_Courses_Hours` varchar(30) DEFAULT NULL,
  `CRI_Core_Courses_Prerequisite` varchar(30) DEFAULT NULL,
  `CRI_Major_Based_Code` varchar(30) DEFAULT NULL,
  `CRI_Major_Based_Title` varchar(30) DEFAULT NULL,
  `CRI_Major_Based_Hours` varchar(30) DEFAULT NULL,
  `CRI_Major_Based_Prerequisite` varchar(30) DEFAULT NULL,
  `CRI_Supporting_Sciences_Code` varchar(30) DEFAULT NULL,
  `CRI_Supporting_Sciences_Title` varchar(30) DEFAULT NULL,
  `CRI_Supporting_Sciences_Hours` varchar(30) DEFAULT NULL,
  `CRI_Supporting_Sciences_Prerequisite` varchar(30) DEFAULT NULL,
  `CRI_General_Education_Code` varchar(30) DEFAULT NULL,
  `CRI_General_Education_Title` varchar(30) DEFAULT NULL,
  `CRI_General_Education_Hours` varchar(30) DEFAULT NULL,
  `CRI_General_Education_Prerequisite` varchar(30) DEFAULT NULL,
  `CRI_University_Elective_Code` varchar(30) DEFAULT NULL,
  `CRI_University_Elective_Title` varchar(30) DEFAULT NULL,
  `CRI_University_Elective_Hours` varchar(30) DEFAULT NULL,
  `CRI_University_Elective_Prerequisite` varchar(30) DEFAULT NULL,
  `Emp_Id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emp`
--

CREATE TABLE IF NOT EXISTS `emp` (
  `Emp_Id` varchar(30) NOT NULL,
  `Emp_Name` varchar(30) DEFAULT NULL,
  `Emp_Password` varchar(30) DEFAULT NULL,
  `Emp_Designation` varchar(30) DEFAULT NULL,
  `Emp_Department` varchar(30) DEFAULT NULL,
  `Admin` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `programmonitoring`
--

CREATE TABLE IF NOT EXISTS `programmonitoring` (
`PM_Form_Id` int(10) NOT NULL,
  `PM_Submit_Date` date DEFAULT NULL,
  `PM_Assign_Date` date DEFAULT NULL,
  `PM_Status` varchar(20) DEFAULT NULL,
  `PM_Post_Time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `PM_InstituteName` varchar(30) DEFAULT NULL,
  `PM_Evaluation` varchar(30) DEFAULT NULL,
  `PM_Howfar` varchar(50) DEFAULT NULL,
  `PM_Howfrequent` varchar(50) DEFAULT NULL,
  `PM_Summaryof_Problems` varchar(50) DEFAULT NULL,
  `PM_Summaryof_Technologies` varchar(50) DEFAULT NULL,
  `PM_Assessment` varchar(50) DEFAULT NULL,
  `PM_Howfar_Program` varchar(50) DEFAULT NULL,
  `PM_Application` varchar(50) DEFAULT NULL,
  `Emp_Id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requestforevaluation`
--

CREATE TABLE IF NOT EXISTS `requestforevaluation` (
`RfeForm_Id` int(10) NOT NULL,
  `Date_To_Be_Submitted` date DEFAULT NULL,
  `Assign_Date` date DEFAULT NULL,
  `Rfe_Status` varchar(50) DEFAULT NULL,
  `RfeInstituteName` varchar(50) DEFAULT NULL,
  `RfeEvaluate` varchar(50) DEFAULT NULL,
  `RfeInstituition` varchar(150) DEFAULT NULL,
  `RfeFederal` varchar(20) DEFAULT NULL,
  `RfeProvincial` varchar(50) DEFAULT NULL,
  `RfeDateGranted` varchar(50) DEFAULT NULL,
  `Emp_Id` varchar(30) DEFAULT NULL,
  `Ref_Post_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requestforevaluationbb`
--

CREATE TABLE IF NOT EXISTS `requestforevaluationbb` (
  `Rfeb_Program_Evaluated` varchar(100) DEFAULT NULL,
  `Rfeb_Type` varchar(30) DEFAULT NULL,
  `Rfeb_Degree` varchar(30) DEFAULT NULL,
  `Rfeb_years` varchar(20) DEFAULT NULL,
  `Rfeb_Initial` varchar(30) DEFAULT NULL,
  `RfeForm_Id` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requestforevaluationpart2`
--

CREATE TABLE IF NOT EXISTS `requestforevaluationpart2` (
  `RfeForm_Id` int(10) DEFAULT NULL,
  `RfePartB_BOG` varchar(50) DEFAULT NULL,
  `RfePartB_Officer` varchar(50) DEFAULT NULL,
  `RfePartB_All_Departments` int(50) DEFAULT NULL,
  `RfePartB_All_Disciplines` varchar(50) DEFAULT NULL,
  `RfePartB_All_Bachelor` int(50) DEFAULT NULL,
  `RfePartB_All_Graduate` int(50) DEFAULT NULL,
  `RfePartB_Total_Students_Graduated` int(50) DEFAULT NULL,
  `RfePartB_Department_Based_Strength_Faculty` int(50) DEFAULT NULL,
  `RfePartB_Program_Based` varchar(50) DEFAULT NULL,
  `RfePartB_Department_Based_Strength_Students` int(50) DEFAULT NULL,
  `RfePartB_Total_Strength_Supporting` int(11) DEFAULT NULL,
  `RfePartB_Total_Number_Students` int(11) DEFAULT NULL,
  `RfePartB_Labs` int(11) DEFAULT NULL,
  `RfePartB_Based_Labs` int(11) DEFAULT NULL,
  `RfePartB_Books` int(11) DEFAULT NULL,
  `RfePartB_Journals` int(11) DEFAULT NULL,
  `RfePartB_Rooms` int(11) DEFAULT NULL,
  `RfeForm_Total_Strength_Faculty` int(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requestforevaluationpartcc`
--

CREATE TABLE IF NOT EXISTS `requestforevaluationpartcc` (
  `aname` varchar(50) NOT NULL,
  `aaddress` varchar(50) NOT NULL,
  `bcity` varchar(100) NOT NULL,
  `bcode` varchar(100) NOT NULL,
  `bgeneral` varchar(100) NOT NULL,
  `burl` varchar(100) NOT NULL,
  `bname` varchar(100) NOT NULL,
  `btitle` varchar(100) NOT NULL,
  `bphone` varchar(100) NOT NULL,
  `bemail` varchar(100) NOT NULL,
  `bfax` varchar(100) NOT NULL,
  `baddress` varchar(100) NOT NULL,
  `cname` varchar(100) NOT NULL,
  `ctitle` varchar(100) NOT NULL,
  `cphone` varchar(100) NOT NULL,
  `cemail` varchar(100) NOT NULL,
  `cfax` varchar(100) NOT NULL,
  `caddress` varchar(100) NOT NULL,
  `dliaison` varchar(100) NOT NULL,
  `dtitle` varchar(100) NOT NULL,
  `dphone` varchar(100) NOT NULL,
  `dfax` varchar(100) NOT NULL,
  `daddress` varchar(100) NOT NULL,
  `ename` varchar(100) NOT NULL,
  `etitle` varchar(100) NOT NULL,
  `ephone` varchar(100) NOT NULL,
  `eemail` varchar(100) NOT NULL,
  `efax` varchar(100) NOT NULL,
  `eaddress` varchar(100) NOT NULL,
  `RfeForm_Id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `studentinformation`
--

CREATE TABLE IF NOT EXISTS `studentinformation` (
`StudentInformation_Form_Id` int(10) NOT NULL,
  `StudentInformation_Instituition` varchar(100) DEFAULT NULL,
  `StudentInformation_Evaluation` varchar(100) DEFAULT NULL,
  `Average_Matriculationyear1` varchar(30) DEFAULT NULL,
  `Average_Matriculationyear2` varchar(30) DEFAULT NULL,
  `Average_Matriculation3` varchar(30) DEFAULT NULL,
  `Average_Fscyear1` varchar(30) DEFAULT NULL,
  `Average_Fscyear2` varchar(30) DEFAULT NULL,
  `Average_Fscyear3` varchar(30) DEFAULT NULL,
  `Byear1` varchar(30) DEFAULT NULL,
  `Byear2` varchar(30) DEFAULT NULL,
  `Byear3` varchar(30) DEFAULT NULL,
  `Byear4` varchar(30) DEFAULT NULL,
  `Byear15` varchar(30) DEFAULT NULL,
  `Cyear1` varchar(30) DEFAULT NULL,
  `Cyear2` varchar(30) DEFAULT NULL,
  `Cyear3` varchar(30) DEFAULT NULL,
  `Cyear4` varchar(30) DEFAULT NULL,
  `Cyear5` varchar(30) DEFAULT NULL,
  `DOutOfClass` varchar(300) DEFAULT NULL,
  `StudentInformation_Post_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Studentformation_Submit_Date` date DEFAULT NULL,
  `StudentInformation_Assign_Date` date DEFAULT NULL,
  `StudentInformation_Status` varchar(30) DEFAULT NULL,
  `Emp_Id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adminstructure`
--
ALTER TABLE `adminstructure`
 ADD PRIMARY KEY (`AdminStructure_Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `adminstructureb`
--
ALTER TABLE `adminstructureb`
 ADD KEY `AdminStructure_Form_Id` (`AdminStructure_Form_Id`);

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
 ADD PRIMARY KEY (`Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `coursedescription`
--
ALTER TABLE `coursedescription`
 ADD PRIMARY KEY (`Course_Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `courselog`
--
ALTER TABLE `courselog`
 ADD PRIMARY KEY (`CourseLog_Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `coursemonitoring`
--
ALTER TABLE `coursemonitoring`
 ADD PRIMARY KEY (`coursemonitoring_Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `courseregistration`
--
ALTER TABLE `courseregistration`
 ADD PRIMARY KEY (`CR_Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `curriculumrelatedinformation`
--
ALTER TABLE `curriculumrelatedinformation`
 ADD PRIMARY KEY (`CRI_Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `emp`
--
ALTER TABLE `emp`
 ADD PRIMARY KEY (`Emp_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `programmonitoring`
--
ALTER TABLE `programmonitoring`
 ADD PRIMARY KEY (`PM_Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- Indexes for table `requestforevaluation`
--
ALTER TABLE `requestforevaluation`
 ADD PRIMARY KEY (`RfeForm_Id`), ADD KEY `Emp_Id` (`Emp_Id`), ADD KEY `Emp_Id_2` (`Emp_Id`);

--
-- Indexes for table `requestforevaluationbb`
--
ALTER TABLE `requestforevaluationbb`
 ADD KEY `RfeForm_Id` (`RfeForm_Id`);

--
-- Indexes for table `requestforevaluationpart2`
--
ALTER TABLE `requestforevaluationpart2`
 ADD KEY `RfeForm_Id` (`RfeForm_Id`);

--
-- Indexes for table `requestforevaluationpartcc`
--
ALTER TABLE `requestforevaluationpartcc`
 ADD KEY `RfeForm_Id` (`RfeForm_Id`);

--
-- Indexes for table `studentinformation`
--
ALTER TABLE `studentinformation`
 ADD PRIMARY KEY (`StudentInformation_Form_Id`), ADD KEY `Emp_Id` (`Emp_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adminstructure`
--
ALTER TABLE `adminstructure`
MODIFY `AdminStructure_Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
MODIFY `Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `coursedescription`
--
ALTER TABLE `coursedescription`
MODIFY `Course_Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `courselog`
--
ALTER TABLE `courselog`
MODIFY `CourseLog_Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `coursemonitoring`
--
ALTER TABLE `coursemonitoring`
MODIFY `coursemonitoring_Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `courseregistration`
--
ALTER TABLE `courseregistration`
MODIFY `CR_Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `curriculumrelatedinformation`
--
ALTER TABLE `curriculumrelatedinformation`
MODIFY `CRI_Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `programmonitoring`
--
ALTER TABLE `programmonitoring`
MODIFY `PM_Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `requestforevaluation`
--
ALTER TABLE `requestforevaluation`
MODIFY `RfeForm_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `studentinformation`
--
ALTER TABLE `studentinformation`
MODIFY `StudentInformation_Form_Id` int(10) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `adminstructure`
--
ALTER TABLE `adminstructure`
ADD CONSTRAINT `adminstructure_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `adminstructureb`
--
ALTER TABLE `adminstructureb`
ADD CONSTRAINT `adminstructureb_ibfk_1` FOREIGN KEY (`AdminStructure_Form_Id`) REFERENCES `adminstructure` (`AdminStructure_Form_Id`);

--
-- Constraints for table `admission`
--
ALTER TABLE `admission`
ADD CONSTRAINT `admission_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `coursedescription`
--
ALTER TABLE `coursedescription`
ADD CONSTRAINT `coursedescription_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `courselog`
--
ALTER TABLE `courselog`
ADD CONSTRAINT `courselog_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `coursemonitoring`
--
ALTER TABLE `coursemonitoring`
ADD CONSTRAINT `coursemonitoring_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `courseregistration`
--
ALTER TABLE `courseregistration`
ADD CONSTRAINT `courseregistration_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `curriculumrelatedinformation`
--
ALTER TABLE `curriculumrelatedinformation`
ADD CONSTRAINT `curriculumrelatedinformation_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `programmonitoring`
--
ALTER TABLE `programmonitoring`
ADD CONSTRAINT `programmonitoring_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `requestforevaluation`
--
ALTER TABLE `requestforevaluation`
ADD CONSTRAINT `requestforevaluation_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

--
-- Constraints for table `requestforevaluationbb`
--
ALTER TABLE `requestforevaluationbb`
ADD CONSTRAINT `requestforevaluationbb_ibfk_1` FOREIGN KEY (`RfeForm_Id`) REFERENCES `requestforevaluation` (`RfeForm_Id`);

--
-- Constraints for table `requestforevaluationpart2`
--
ALTER TABLE `requestforevaluationpart2`
ADD CONSTRAINT `requestforevaluationpart2_ibfk_1` FOREIGN KEY (`RfeForm_Id`) REFERENCES `requestforevaluationbb` (`RfeForm_Id`);

--
-- Constraints for table `requestforevaluationpartcc`
--
ALTER TABLE `requestforevaluationpartcc`
ADD CONSTRAINT `requestforevaluationpartcc_ibfk_1` FOREIGN KEY (`RfeForm_Id`) REFERENCES `requestforevaluation` (`RfeForm_Id`);

--
-- Constraints for table `studentinformation`
--
ALTER TABLE `studentinformation`
ADD CONSTRAINT `studentinformation_ibfk_1` FOREIGN KEY (`Emp_Id`) REFERENCES `emp` (`Emp_Id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
