<?php	
include 'header.php';
?>
  
  <body>
 
    <div class="section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="panel panel-primary">
              <div class="panel-heading"> <h4>Profile</h4>
                    </div>
              <div class="panel-body">
                <div class="col-md-12 text-left">
                  <div class="profile clearfix">
                    <div class="user clearfix">
                      <div class="avatar">
                        <img src="images/240x160.jpg" class=" img-responsive img-rounded img-profile" style="width: 110px;height: 110px">
                      </div>
                      <h3>Name</h3>
                    </div>
                    <div class="info">
                      <p class="text-left">
                        <span class="glyphicon glyphicon-globe"></span>
                        <span class="title">Department:</span>&nbsp;Department</p>
                      <p>
                        <span class="glyphicon glyphicon-briefcase"></span>
                        <span class="title">Designation:</span>&nbsp;Designation</p>
                      <p>
                        <span class="glyphicon glyphicon-gift"></span>
                        <span class="title">Date of Birth:</span>&nbsp;01.01.2015</p>
                    </div>
                   <p>&nbsp;</p>
                        <div class="container-fluid text-center">
                          <button type="button" class="btn btn-primary btn-sm">Save</button>
                          <button type="button" class="btn btn-primary btn-sm">&nbsp;Cancel</button>
                        </div>

				  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  

</body></html>